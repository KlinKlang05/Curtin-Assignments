COMP2006 assignment 1 2024

Kevin Kongo 21473719

files:
mssv.c
mssv.o
threading.c
threading.h
components.c
components.h
makefile
solution.txt
solution1.txt
solution2.txt
generate_test_case.py

to complile the program: in Linux terminal, open the path to the code. then run the command:

make

This will execute the makefile and compile the code. Ensure GCC is installed.
To run the program:

mssv solution delay

Where solution is the file that contains the Sudoku Solution to be validated, and delay is an integer with a value between 1 and 10.

Three solution files are provided: solution.txt, solution1.txt, and solution2.txt. The first one is a valid solution while the other two are not.

