#ifndef FILEIO_H
#define FILEIO_H
#define BOARD_SIZE 9 

int importSolution(char* filename, int** board);

#endif 